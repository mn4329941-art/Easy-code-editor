package com.example.onlinepython

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import io.github.rosemoe.sora.langs.python.PythonLanguage
import io.github.rosemoe.sora.text.Content
import io.github.rosemoe.sora.widget.CodeEditor
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var editor: CodeEditor
    private lateinit var console: TextView
    private lateinit var consoleScroll: ScrollView

    private lateinit var btnRun: Button
    private lateinit var btnSave: Button
    private lateinit var btnNew: Button
    private lateinit var btnOpen: Button
    private lateinit var btnSaveAs: Button

    // Open document launcher (Storage Access Framework)
    private val openFileLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            contentResolver.openInputStream(it)?.use { input ->
                val text = input.bufferedReader().readText()
                editor.setText(Content(text))
                appendConsole("# تم فتح الملف: $uri")
            }
        }
    }

    // Create document launcher (Save As)
    private val saveFileLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri: Uri? ->
        uri?.let {
            contentResolver.openOutputStream(it)?.use { output ->
                output.write(editor.text.toString().toByteArray())
                appendConsole("# تم الحفظ في: $uri")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // views
        editor = findViewById(R.id.editor)
        console = findViewById(R.id.console)
        consoleScroll = findViewById(R.id.consoleScroll)

        btnRun = findViewById(R.id.btnRun)
        btnSave = findViewById(R.id.btnSave)
        btnNew = findViewById(R.id.btnNew)
        btnOpen = findViewById(R.id.btnOpen)
        btnSaveAs = findViewById(R.id.btnSaveAs)

        // Configure CodeEditor for Python
        editor.setEditorLanguage(PythonLanguage())
        editor.setText(Content("print('Hello from Chaquopy + Editor!')"))

        // Initialize Chaquopy Python runtime
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }
        val py = Python.getInstance()

        // Button behaviors
        btnRun.setOnClickListener {
            runCode(py, editor.text.toString())
        }

        btnSave.setOnClickListener {
            saveToLocal(editor.text.toString())
            appendConsole("# الملف محفوظ محليًا")
        }

        btnNew.setOnClickListener {
            editor.setText(Content(""))
        }

        btnOpen.setOnClickListener {
            // Allow selecting .py or plain text
            openFileLauncher.launch(arrayOf("text/x-python", "text/plain"))
        }

        btnSaveAs.setOnClickListener {
            saveFileLauncher.launch("script.py")
        }
    }

    private fun runCode(py: Python, code: String) {
        appendConsole("# تشغيل...")
        try {
            val module = py.getModule("runner")
            val result = module.callAttr("run", code)
            val out = result.toString()
            if (out.isBlank()) {
                appendConsole("# انتهى التنفيذ — لا مخرجات.")
            } else {
                appendConsole(out)
            }
        } catch (e: Exception) {
            appendConsole("# خطأ أثناء التنفيذ: " + e.message)
        }
    }

    private fun appendConsole(text: String) {
        runOnUiThread {
            val old = console.text.toString()
            val newText = if (old.isEmpty()) text else old + "\n" + text
            console.text = newText
            // Scroll to bottom
            consoleScroll.post { consoleScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun saveToLocal(content: String) {
        val f = File(filesDir, "script.py")
        f.writeText(content)
    }
}
