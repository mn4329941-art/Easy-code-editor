# runner.py
import sys
import io
import traceback

def run(code: str) -> str:
    """Execute Python code and return combined stdout+stderr as string."""
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    buf = io.StringIO()
    sys.stdout = buf
    sys.stderr = buf
    try:
        exec_globals = {}
        exec(code, exec_globals)
    except Exception:
        traceback.print_exc()
    finally:
        sys.stdout = old_stdout
        sys.stderr = old_stderr
    return buf.getvalue()
