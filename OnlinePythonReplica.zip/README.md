# OnlinePythonReplica (Android)
هذا مشروع Android Studio جاهز كتجهيز أولي لتطبيق محرر Python أوفلاين:
- محرر CodeEditor (Rosemoe) مع تلوين syntax للبايثون
- تنفيذ كود بايثون أوفلاين باستخدام Chaquopy (runner.py)
- فتح/حفظ ملفات .py عبر Storage Access Framework

**كيفية الاستخدام**
1. افتح المشروع في Android Studio.
2. تأكد أن Gradle وAndroid Studio عَصِرَة التوافق مع الإعدادات.
3. شغّل (Run) على جهاز أو محاكي.
4. اضغط Run داخل التطبيق لتنفيذ الكود.

**ملاحظة:** Chaquopy سيحمّل runtime أثناء بناء المشروع؛ قد يزيد حجم الـ APK.
